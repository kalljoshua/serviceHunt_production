<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewsLetterLogs extends Model
{
    //
}
