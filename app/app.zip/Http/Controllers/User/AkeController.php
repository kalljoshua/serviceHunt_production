<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AkeController extends Controller
{
    public function index(){
      return "Howdy de!";
    }
}
